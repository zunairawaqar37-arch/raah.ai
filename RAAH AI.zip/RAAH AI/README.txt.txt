How to use this code: 
1) Firstly, open the terminal and Make a Virtual environment using the command: uv venv
2) Activate the Virtual environment using the command: uv venv activate or open another terminal (CMD) and it will be automatically activated.
to verify if the virtual environment is activated, check the terminal prompt. It should start with (venv).
3) Install the packages using the command: uv pip install -r requriements.txt
4) Use your own api key from groq.com and paste it in the .env file in the src folder.
5) Run the app.py using the command: streamlit run app.py
